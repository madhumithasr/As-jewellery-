# Multi-Account System - User Flow Preview

## 🏠 HOME SCREEN - Account Switcher

When you login, you'll see this at the top of the home screen:

```
┌─────────────────────────────────────────────────────────┐
│  Welcome back,                    📊 Today's Gold Rate  │
│  John Doe                              ₹6,500/g         │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  💼 Primary Account                               ▼     │
│     INV111111-001                                       │
└─────────────────────────────────────────────────────────┘
         ⬆️ CLICK HERE TO SWITCH ACCOUNTS

┌─────────────────────────────────────────────────────────┐
│  Total Balance                                          │
│  ₹25,450.00                                            │
│                                                         │
│  Savings: ₹20,000.00  │  Referral: ₹5,450.00         │
└─────────────────────────────────────────────────────────┘
```

## 📱 SWITCHING ACCOUNTS

### Step 1: Click the Account Switcher
When you click on the account box, a modal slides up from bottom:

```
═══════════════════════════════════════════════════════════
                    Switch Account                    ✕
═══════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────┐
│  💼 Primary Account                    [PRIMARY]  ✓     │
│     INV111111-001                                       │
│     🟢 KYC Verified                                     │
└─────────────────────────────────────────────────────────┘
         ⬆️ YOUR CURRENT ACCOUNT (Green checkmark)

┌─────────────────────────────────────────────────────────┐
│  💰 Family Savings                                      │
│     INV111111-002                                       │
│     🟢 KYC Verified                                     │
└─────────────────────────────────────────────────────────┘
         ⬆️ CLICK TO SWITCH TO THIS ACCOUNT

┌─────────────────────────────────────────────────────────┐
│  🏢 Business Investment                                 │
│     INV111111-003                                       │
│     🟠 KYC Pending                                      │
└─────────────────────────────────────────────────────────┘
         ⬆️ ANOTHER ACCOUNT (Orange = needs KYC)

┌─────────────────────────────────────────────────────────┐
│                  ➕ Add New Account                     │
│         Add another investment account                  │
│              (7 slots remaining)                        │
└─────────────────────────────────────────────────────────┘
         ⬆️ CLICK TO CREATE NEW ACCOUNT

┌─────────────────────────────────────────────────────────┐
│              [Manage Accounts]                          │
└─────────────────────────────────────────────────────────┘
```

### Step 2: After Switching
When you tap "Family Savings", the modal closes and:
- Home screen instantly updates to show Family Savings data
- Account switcher now shows "Family Savings - INV111111-002"
- All wallet balances, transactions update to that account
- Gold holdings show only for that account

## ➕ ADDING NEW ACCOUNT

### Method 1: From Account Switcher
Click "➕ Add New Account" in the switcher modal

### Method 2: From Manage Accounts Screen
Click "Manage Accounts" button at bottom of switcher

## 📋 MANAGE ACCOUNTS SCREEN

Full-screen view showing all your accounts:

```
┌─────────────────────────────────────────────────────────┐
│  ←  My Accounts                                         │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│              Total Accounts                             │
│                  3 / 10                                 │
│    You can create up to 7 more accounts                │
└─────────────────────────────────────────────────────────┘

━━━━━━━━━ Your Investment Accounts ━━━━━━━━━━

┌─────────────────────────────────────────────────────────┐
│  💼 Primary Account  [PRIMARY]         [ACTIVE]         │
│     INV111111-001                                       │
│     ✓ KYC Verified                                      │
│     Verified on 10/11/2025                             │
│                                                         │
│     Aadhar: ****5678                                   │
│     PAN: ABCDE1234F                                    │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  💰 Family Savings                                      │
│     INV111111-002                                       │
│     ✓ KYC Verified                                      │
│     Verified on 12/11/2025                             │
│                                                         │
│  [Switch to this Account]                              │
│                                                         │
│     Aadhar: ****9012                                   │
│     PAN: FGHIJ5678K                                    │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  🏢 Business Investment                                 │
│     INV111111-003                                       │
│     ⚠️ KYC Pending                                      │
│                                                         │
│  [Switch to this Account]                              │
│  [🛡️ Complete KYC]                                      │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                  ➕                                     │
│          Create New Account                             │
│   Add another investment account (7 slots remaining)    │
└─────────────────────────────────────────────────────────┘
         ⬆️ CLICK TO ADD ACCOUNT

━━━━━━━━━ About Multiple Accounts ━━━━━━━━━━

• You can create up to 10 investment accounts
• Each account needs separate KYC verification
• Each account has its own wallet and investments
• Switch between accounts anytime from the home screen
• Only your primary account can refer other users
```

## 🆕 CREATING NEW ACCOUNT FLOW

### Step 1: Click "Create New Account"
A modal appears:

```
═══════════════════════════════════════════════════════════
              Create New Account

      Enter a name for your new investment account
═══════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────┐
│  [Account Name (e.g., Family Savings)               ]  │
└─────────────────────────────────────────────────────────┘

[Cancel]                        [Create Account]
```

### Step 2: Enter Account Name
Example: "Children's Education Fund"

### Step 3: Account Created
```
═══════════════════════════════════════════════════════════
                      Success!
        Account created successfully
═══════════════════════════════════════════════════════════

Your new account has been created:

Account Name: Children's Education Fund
Account Number: INV111111-004

[OK]
```

### Step 4: New Account Appears in List
```
┌─────────────────────────────────────────────────────────┐
│  🎓 Children's Education Fund                           │
│     INV111111-004                                       │
│     ⚠️ KYC Pending                                      │
│                                                         │
│  [Switch to this Account]                              │
│  [🛡️ Complete KYC]                                      │
└─────────────────────────────────────────────────────────┘
```

## 🛡️ KYC VERIFICATION FOR NEW ACCOUNT

### Step 1: Click "Complete KYC"
Opens KYC verification screen:

```
┌─────────────────────────────────────────────────────────┐
│  ←  KYC Verification                                    │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  Children's Education Fund                              │
│  INV111111-004                                          │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│              🛡️                                         │
│        Complete Your KYC                                │
│                                                         │
│  Please provide your Aadhar and PAN details for this    │
│  investment account. Each account requires separate      │
│  KYC verification.                                       │
└─────────────────────────────────────────────────────────┘

Aadhar Number
┌─────────────────────────────────────────────────────────┐
│  [Enter 12-digit Aadhar number                       ]  │
└─────────────────────────────────────────────────────────┘
Enter your 12-digit Aadhar card number

PAN Number
┌─────────────────────────────────────────────────────────┐
│  [Enter PAN (e.g., ABCDE1234F)                       ]  │
└─────────────────────────────────────────────────────────┘
Enter your 10-character PAN number

┌─────────────────────────────────────────────────────────┐
│              Important Notice                           │
│  • All details will be verified by admin                │
│  • Ensure details match your official documents         │
│  • Each account needs unique Aadhar & PAN              │
│  • Verification typically takes 1-2 business days       │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│        [Submit for Verification]                        │
└─────────────────────────────────────────────────────────┘
```

### Step 2: Fill Details
```
Aadhar Number
┌─────────────────────────────────────────────────────────┐
│  234567891234                                           │
└─────────────────────────────────────────────────────────┘

PAN Number
┌─────────────────────────────────────────────────────────┐
│  KLMNO6789P                                             │
└─────────────────────────────────────────────────────────┘
```

### Step 3: Submit & Success
```
═══════════════════════════════════════════════════════════
                    Success!

      KYC details submitted successfully.
      Please wait for admin verification.
═══════════════════════════════════════════════════════════

[OK]
```

## 🔄 COMPLETE WORKFLOW SUMMARY

```
Login → Home Screen
   │
   ├─→ Click Account Switcher
   │      │
   │      ├─→ Switch to Existing Account → Home Updates
   │      │
   │      └─→ Add New Account → Enter Name → Account Created
   │
   └─→ Click "Manage Accounts"
          │
          ├─→ View All Accounts
          │
          ├─→ Create New Account → Enter Name → Account Created
          │
          └─→ Click "Complete KYC" → Enter Aadhar & PAN → Submit
                                      ↓
                                Admin Verifies
                                      ↓
                                KYC Approved ✓
                                      ↓
                        Account Ready for Transactions
```

## 📊 REAL EXAMPLE SCENARIO

### User: Rajesh Kumar

**Account 1 (Primary):**
- Name: "Primary Account"
- Number: INV111111-001
- Aadhar: ****5678
- PAN: ABCDE1234F
- Status: ✓ KYC Verified
- Wallet: ₹25,000
- Can refer others: Yes

**Account 2:**
- Name: "Wife's Gold Savings"
- Number: INV111111-002
- Aadhar: ****9012
- PAN: FGHIJ5678K
- Status: ✓ KYC Verified
- Wallet: ₹18,500
- Can refer others: No

**Account 3:**
- Name: "Children's Education"
- Number: INV111111-003
- Aadhar: ****3456
- PAN: KLMNO9012L
- Status: ✓ KYC Verified
- Wallet: ₹32,000
- Can refer others: No

**Account 4:**
- Name: "Business Investment"
- Number: INV111111-004
- Aadhar: Not entered yet
- PAN: Not entered yet
- Status: ⚠️ KYC Pending
- Wallet: ₹0 (cannot invest until KYC verified)
- Can refer others: No

### Daily Usage:

**Morning:** Switch to "Primary Account" to check referral earnings
**Afternoon:** Switch to "Wife's Gold Savings" to make monthly payment
**Evening:** Switch to "Children's Education" to view gold balance

Each account completely separate - no data mixing!

## 🎨 UI DESIGN FEATURES

### Colors:
- **Gold (#FFD700):** Primary account badge, buttons, highlights
- **Green (#4ade80):** KYC verified status, active account
- **Orange (#f59e0b):** KYC pending status, warning badges
- **Dark (#1a1a1a):** Background
- **Gray (#999):** Secondary text

### Icons:
- 💼 Primary Account
- 💰 Savings Account
- 🏢 Business Account
- 🎓 Education Account
- ✓ Verified
- ⚠️ Pending
- ➕ Add New
- 🛡️ KYC Security

### Badges:
- **[PRIMARY]** - Yellow/Gold background
- **[ACTIVE]** - Green background
- **🟢 KYC Verified** - Green dot
- **🟠 KYC Pending** - Orange dot

## 🔐 SECURITY NOTES

1. **Account Limit:** Maximum 10 accounts enforced at database level
2. **Unique KYC:** Each account must have different Aadhar + PAN
3. **Admin Approval:** All KYC submissions must be verified by admin
4. **Data Isolation:** Each account's data completely separate
5. **Primary Account:** Only the first account can refer others
6. **Masked Data:** Aadhar shown as ****1234 for security

---

**All features are already implemented and working in the codebase!**

The system is production-ready with full functionality for:
- Creating up to 10 accounts
- Switching between accounts
- Separate KYC for each account
- Independent wallets and investments
- Beautiful, intuitive UI design
