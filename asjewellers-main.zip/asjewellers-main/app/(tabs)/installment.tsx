import { useLocalSearchParams, router } from 'expo-router';
import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export default function InstallmentPaymentScreen() {
  const params = useLocalSearchParams<{ planId: string | string[] }>();
  const planId = Array.isArray(params.planId)
    ? params.planId[0]
    : params.planId || '';

  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('UPI');

  const handlePayNow = () => {
    if (!amount || Number(amount) < 100) {
      alert('Minimum installment must be ₹5000');
      return;
    }

    // TODO: Save payment info to Supabase here

    router.push({
      pathname: '/(tabs)/plans',
      params: {
        planId,
        amount,
        method: paymentMethod,
      },
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.screenTitle}>Installment Payment</Text>

      <Text style={styles.subText}>Plan ID: {planId}</Text>

      {/* Amount */}
      <Text style={styles.label}>Enter Installment Amount *</Text>
      <TextInput
        placeholder="₹ Enter amount"
        keyboardType="numeric"
        style={styles.input}
        value={amount}
        onChangeText={setAmount}
      />

      {/* Payment Mode */}
      <Text style={[styles.label, { marginTop: 20 }]}>Select Payment Mode</Text>
      <View style={styles.methodContainer}>
        {['UPI', 'Card', 'NetBanking', 'Cash'].map((method) => (
          <TouchableOpacity
            key={method}
            style={[
              styles.methodButton,
              paymentMethod === method && styles.methodActive,
            ]}
            onPress={() => setPaymentMethod(method)}
          >
            <Text
              style={[
                styles.methodText,
                paymentMethod === method && styles.methodTextActive,
              ]}
            >
              {method}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Pay Button */}
      <TouchableOpacity style={styles.button} onPress={handlePayNow}>
        <Text style={styles.buttonText}>Proceed to Pay</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#000',
    alignItems: 'center',
  },
  screenTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFD700',
    marginBottom: 20,
  },
  subText: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#aaa',
    alignSelf: 'flex-start',
    marginBottom: 5,
  },
  input: {
    width: '100%',
    backgroundColor: '#1a1a1a',
    color: '#fff',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  methodContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginVertical: 10,
    gap: 10,
  },
  methodButton: {
    backgroundColor: '#333',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    marginRight: 10,
    marginBottom: 10,
  },
  methodActive: {
    backgroundColor: '#FFD700',
  },
  methodText: {
    color: '#fff',
    fontWeight: '600',
  },
  methodTextActive: {
    color: '#000',
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: '#FFD700',
    padding: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
    marginTop: 30,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
});
