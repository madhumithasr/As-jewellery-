import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';

export default function PlanScreen() {
  const { planId } = useLocalSearchParams<{ planId: string | string[] }>();

  // Ensure planId is a single string
  const planIdStr = Array.isArray(planId) ? planId[0] : planId || '';

  const userId = 'USER_ID_HERE'; // replace with actual logged-in user ID

  // Static plan details (replace with dynamic fetch later)
  const monthlyAmount = 1500;
  const durationMonths = 12;
  const bonusPercentage = 5; // 10% bonus for example

  const goldRate = 8500;
  const startDate = '01/01/2025';
  const endDate = '01/01/2026';

  const goldSavingGram = ((monthlyAmount * durationMonths) / goldRate).toFixed(
    2
  );

  // Calculate bonus amount
  const bonusAmount = (
    (monthlyAmount * durationMonths * bonusPercentage) /
    100
  ).toFixed(2);

  // Total payable
  const totalPayable = (
    monthlyAmount * durationMonths +
    Number(bonusAmount)
  ).toFixed(2);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.screenTitle}>Plan Details</Text>

      <View style={styles.card}>
        <Detail label="Plan ID" value={planIdStr} />
        <Detail label="Gold Saving Gram" value={`${goldSavingGram}`} />

        <Detail label="User ID" value={userId} />
        <Detail label="Gold Rate" value={`₹ ${goldRate}`} />
        <Detail label="Start Date" value={startDate} />
        <Detail label="End Date" value={endDate} />
        <Detail label="Duration" value={`${durationMonths} months`} />
        <Detail label="Monthly Amount" value={`₹ ${monthlyAmount}`} />
        <Detail label="Bonus" value={`₹ ${bonusAmount}`} />
        <Detail label="Total Payable" value={`₹ ${totalPayable}`} />
      </View>

      <TouchableOpacity
        style={styles.button}
        onPress={() =>
          router.push({
            pathname: '/(tabs)/installment',
            params: { planId },
          })
        }
      >
        <Text style={styles.buttonText}>Pay Confirm</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

// Component for each detail row
function Detail({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailLabel}>{label}:</Text>
      <Text style={styles.detailValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#000',
    alignItems: 'center',
  },
  screenTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFD700',
    marginBottom: 20,
  },
  card: {
    width: '100%',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginBottom: 30,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 6,
  },
  detailLabel: {
    fontSize: 16,
    color: '#aaa',
    fontWeight: '600',
  },
  detailValue: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: '#FFD700',
    padding: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
});
