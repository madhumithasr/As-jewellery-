import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';

export default function ReferralsScreen() {
  const referralCode = 'MADHU123'; // Replace with dynamic Supabase value

  const inviteLink = `https://yourapp.com/ref/${referralCode}`;

  const copyToClipboard = async (text: string) => {
    await Clipboard.setStringAsync(text);
    Alert.alert('Copied!', 'Copied to clipboard.');
  };

  const totalReferralBonus = 400; // You can update dynamically

  const rows = [
    { amount: 150, percent: 10 },
    { amount: 45, percent: 3 },
    { amount: 30, percent: 2 },
    { amount: 22.5, percent: 1.5 },
    { amount: 11.25, percent: 0.75 },
    { amount: 11.25, percent: 0.75 },
    { amount: 7.5, percent: 0.5 },
    { amount: 7.5, percent: 0.5 },
    { amount: 7.5, percent: 0.5 },
    { amount: 7.5, percent: 0.5 },
    // Add more rows easily here
  ];

  const bonus = 200; // Additional bonus included in total

  const totalAmount = rows.reduce((sum, r) => sum + r.amount, 0);
  const totalPercent = rows.reduce((sum, r) => sum + r.percent, 0);

  return (
    <ScrollView style={styles.container}>
      {/* TITLE */}
      <Text style={styles.title}>Referral Program</Text>

      {/* REFERRAL CODE BOX */}
      <View style={styles.box}>
        <Text style={styles.boxTitle}>Your Referral Code</Text>
        <Text style={styles.codeText}>{referralCode}</Text>

        <TouchableOpacity
          style={styles.copyBtn}
          onPress={() => copyToClipboard(referralCode)}
        >
          <Text style={styles.copyText}>Copy Code</Text>
        </TouchableOpacity>
      </View>

      {/* INVITE LINK BOX */}
      <View style={styles.box}>
        <Text style={styles.boxTitle}>Invite Link</Text>
        <Text style={styles.linkText}>{inviteLink}</Text>

        <TouchableOpacity
          style={styles.copyBtn}
          onPress={() => copyToClipboard(inviteLink)}
        >
          <Text style={styles.copyText}>Copy Link</Text>
        </TouchableOpacity>
      </View>

      {/* TOTAL BONUS BOX */}
      <View style={styles.box}>
        <Text style={styles.boxTitle}>Your Referral Bonus</Text>
        <Text style={styles.bonusText}>
          Rs. {totalReferralBonus.toFixed(2)}
        </Text>
      </View>

      {/* PERCENTAGE TABLE */}
      <Text style={styles.tableHeader}>Referral Bonus Percentage Table</Text>

      <View style={styles.tableBox}>
        <View style={styles.row}>
          <Text style={[styles.cell, styles.index]}>#</Text>
          <Text style={[styles.cell, styles.amount]}>Amount</Text>
          <Text style={[styles.cell, styles.percent]}>%</Text>
        </View>

        {rows.map((r, index) => (
          <View key={index} style={styles.row}>
            <Text style={[styles.cell, styles.index]}>{index + 1}</Text>
            <Text style={[styles.cell, styles.amount]}>
              Rs. {r.amount.toFixed(2)}
            </Text>
            <Text style={[styles.cell, styles.percent]}>({r.percent}%)</Text>
          </View>
        ))}

        {/* BONUS ROW */}
        <View style={styles.bonusRow}>
          <Text style={styles.bonusLabel}>Bonus</Text>
          <Text style={styles.bonusValue}>Rs. {bonus.toFixed(2)}</Text>
        </View>

        {/* TOTAL */}
        <View style={styles.totalRow}>
          <Text style={styles.totalText}>
            Total Rs. {(totalAmount + bonus).toFixed(2)} / (
            {totalPercent.toFixed(1)}%)
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 16,
  },
  title: {
    color: 'gold',
    fontSize: 24,
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 16,
  },
  box: {
    backgroundColor: '#111',
    padding: 16,
    borderRadius: 10,
    marginBottom: 14,
    borderColor: 'gold',
    borderWidth: 1,
  },
  boxTitle: {
    color: 'gold',
    fontSize: 16,
    marginBottom: 6,
  },
  codeText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  linkText: {
    color: '#ccc',
    fontSize: 15,
  },
  copyBtn: {
    marginTop: 10,
    backgroundColor: 'gold',
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
  },
  copyText: {
    color: 'black',
    fontWeight: 'bold',
  },
  bonusText: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
  },
  tableHeader: {
    color: 'gold',
    fontSize: 18,
    marginTop: 20,
    marginBottom: 10,
  },
  tableBox: {
    backgroundColor: '#111',
    padding: 10,
    borderRadius: 10,
    borderColor: 'gold',
    borderWidth: 1,
  },
  row: {
    flexDirection: 'row',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  cell: {
    color: 'white',
    fontSize: 14,
  },
  index: {
    width: '10%',
    textAlign: 'center',
  },
  amount: {
    width: '60%',
  },
  percent: {
    width: '30%',
    textAlign: 'right',
  },
  bonusRow: {
    paddingVertical: 8,
  },
  bonusLabel: {
    color: 'gold',
    fontSize: 16,
    fontWeight: 'bold',
  },
  bonusValue: {
    color: 'white',
    fontSize: 16,
  },
  totalRow: {
    padding: 10,
    backgroundColor: '#222',
    borderRadius: 6,
    marginTop: 8,
  },
  totalText: {
    color: 'gold',
    fontSize: 18,
    textAlign: 'center',
    fontWeight: 'bold',
  },
});
